# Iris Modular Project 

Quickstart:

```
conda activate iris-modular
python scripts/train.py
python scripts/predict.py
streamlit run app/streamlit_app.py
```
