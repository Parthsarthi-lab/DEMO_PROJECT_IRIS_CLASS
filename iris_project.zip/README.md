# Iris Modular Project (Beginner-Friendly, Conda, No-Argparse, No-Tests)

Quickstart:

```
conda env create -f environment.yml
conda activate iris-modular
python scripts/train.py
python scripts/predict.py
streamlit run app/streamlit_app.py
```
